﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPxComboBox___How_to_group_items
{
    public class SampleData
    {
        public int Id { get; set; }

        public string Text { get; set; }

        public int? GroupId { get; set; }
        public string GroupName { get; set; }


    
     }
}